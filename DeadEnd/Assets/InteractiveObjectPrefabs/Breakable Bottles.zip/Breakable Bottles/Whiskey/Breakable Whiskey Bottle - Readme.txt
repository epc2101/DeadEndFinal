/****************************************
	Breakable Whiskey Bottle 1.0					
	Copyright 2012 Unluck Software	
 	www.chemicalbliss.com																																				
*****************************************/
Features
• Scaleable Whiskey Prefab
• Drag & Drop
• 2048×2048px texture and normal map
• Scene included
• Layered texture workfile included

Each variable is explained in the script as comments as well as the custom editor interface.
Go back to classic editor by simply deleting BreakableObjectEditor.js.

Thanks for purchasing this prefab
Have fun with Unity :)